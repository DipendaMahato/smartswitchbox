import { ArrowRight } from 'lucide-react';
import { useState, useEffect } from 'react';

export function Home() {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const slides = [
    {
      image: 'https://i.ibb.co/WYWCSJd/Whats-App-Image-2025-03-22-at-00-12-45-41083787.jpg',
      quote: 'Revolutionizing Smart Living – One Innovation at a Time.'
    },
    {
      image: 'https://i.ibb.co/FqLtfqkW/Whats-App-Image-2025-03-22-at-00-15-59-3ae3bde6.jpg',
      quote: 'Seamless Control, Effortless Convenience – Experience the Future of Smart Automation.'
    },
    {
      image: 'https://i.ibb.co/CpCtspPv/Whats-App-Image-2025-03-22-at-00-18-18-56178cb8.jpg',
      quote: 'Smarter Technology, Greater Efficiency – Redefining the Way You Live.'
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="home" className="min-h-screen relative overflow-hidden">
      {/* Background gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 to-purple-600/10 z-10" />
      
      {/* Image carousel background */}
      <div className="absolute inset-0 z-0">
        {slides.map((slide, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <img
              src={slide.image}
              alt={`Smart home automation ${index + 1}`}
              className="w-full h-full object-cover"
            />
          </div>
        ))}
      </div>

      {/* Content */}
      <div className="relative z-20 container mx-auto px-4 h-screen flex items-center">
        <div className="max-w-2xl backdrop-blur-sm bg-black/10 p-8 rounded-xl">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Smart Multifunction Switch Box
          </h1>
          <p className="text-xl text-white mb-8 leading-relaxed">
            Transform your home into a smart paradise with our innovative IoT solution. 
            Control, monitor, and automate your electrical devices with ease.
          </p>
          <div className="flex gap-4">
            <a
              href="https://www.researchgate.net/publication/387485588_IoT_Based_Smart_Multi-function_Switch_Box"
              target="_blank"
              rel="noopener noreferrer"
              className="button-primary flex items-center gap-2 bg-transparent border-2 border-white hover:bg-white/10 px-8 py-4"
            >
              <span>Learn More</span>
              <ArrowRight className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>

      {/* Slide indicators */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 z-20 flex gap-2">
        {slides.map((_, index) => (
          <button
            key={index}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentSlide ? 'bg-white scale-125' : 'bg-white/50'
            }`}
            onClick={() => setCurrentSlide(index)}
          />
        ))}
      </div>
    </section>
  );
}