import { Wifi, Bluetooth, Mic, TowerControl as RemoteControl, Calendar, LineChart as ChartLine, Shield, Expand } from 'lucide-react';

export function Features() {
  const features = [
    {
      icon: <Wifi className="w-8 h-8" />,
      title: "Multi-Connectivity Options",
      description: "Control via Wi-Fi, Bluetooth, voice commands, and remote control integration"
    },
    {
      icon: <Calendar className="w-8 h-8" />,
      title: "Smart Automation",
      description: "Set schedules and automate based on usage patterns"
    },
    {
      icon: <ChartLine className="w-8 h-8" />,
      title: "Energy Monitoring",
      description: "Real-time power consumption tracking with custom alerts"
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Safety Features",
      description: "Built-in fault detection and surge protection"
    },
    {
      icon: <Expand className="w-8 h-8" />,
      title: "Expandability",
      description: "Modular design supporting both old and new appliances"
    }
  ];

  return (
    <section id="features" className="section bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12 text-gray-900">Features</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="card hover:scale-105 transition-transform duration-300">
              <div className="text-primary mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}