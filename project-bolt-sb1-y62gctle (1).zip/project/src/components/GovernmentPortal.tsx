import { Building2, FileText, MessageSquare } from 'lucide-react';
import { useState } from 'react';

const MOCK_BILLS: Record<string, number> = {
  'BILL001': 1500,
  'BILL002': 2300,
  'BILL003': 1800,
  'BILL004': 2700,
  'BILL005': 3200,
};

export function GovernmentPortal() {
  const [billNumber, setBillNumber] = useState('');
  const [billAmount, setBillAmount] = useState<number | null>(null);
  const [showPaymentSuccess, setShowPaymentSuccess] = useState(false);
  const [showComplaintSuccess, setShowComplaintSuccess] = useState(false);

  const handleBillCheck = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = MOCK_BILLS[billNumber];
    if (amount) {
      setBillAmount(amount);
    } else {
      setBillAmount(Math.floor(Math.random() * (5000 - 1000) + 1000));
    }
  };

  const handlePayment = (e: React.FormEvent) => {
    e.preventDefault();
    setShowPaymentSuccess(true);
    setTimeout(() => setShowPaymentSuccess(false), 5000);
  };

  const handleComplaint = (e: React.FormEvent) => {
    e.preventDefault();
    setShowComplaintSuccess(true);
    setTimeout(() => setShowComplaintSuccess(false), 5000);
  };

  return (
    <section id="government-portal" className="section bg-gradient-to-br from-green-50 to-emerald-50">
      <div className="container mx-auto">
        <h2 className="text-4xl font-bold text-center mb-12 bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
          Government Portal
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Billing Information */}
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-green-200">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 bg-gradient-to-br from-green-500 to-emerald-500 rounded-lg">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                Check Billing
              </h3>
            </div>
            <form onSubmit={handleBillCheck} className="space-y-4">
              <input
                type="text"
                placeholder="Bill Number (e.g., BILL001)"
                value={billNumber}
                onChange={(e) => setBillNumber(e.target.value)}
                className="w-full px-4 py-3 rounded-lg border border-green-200 focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white/70"
              />
              <button type="submit" className="w-full py-3 px-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-lg hover:opacity-90 transition-opacity">
                Check Billing
              </button>
              {billAmount !== null && (
                <div className="mt-4 p-6 bg-gradient-to-br from-green-50/50 to-emerald-50/50 rounded-lg border border-green-200">
                  <p className="text-green-800 font-semibold mb-2">Bill Amount:</p>
                  <p className="text-3xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                    ₹{billAmount.toFixed(2)}
                  </p>
                </div>
              )}
            </form>
          </div>

          {/* Bill Payment */}
          <div className="bg-gradient-to-br from-teal-50 to-cyan-50 p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-teal-200">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 bg-gradient-to-br from-teal-500 to-cyan-500 rounded-lg">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold bg-gradient-to-r from-teal-600 to-cyan-600 bg-clip-text text-transparent">
                Pay Bill
              </h3>
            </div>
            <form onSubmit={handlePayment} className="space-y-4">
              <input
                type="text"
                placeholder="Bill Number"
                className="w-full px-4 py-3 rounded-lg border border-teal-200 focus:ring-2 focus:ring-teal-500 focus:border-transparent bg-white/70"
                required
              />
              <input
                type="number"
                placeholder="Amount (₹)"
                className="w-full px-4 py-3 rounded-lg border border-teal-200 focus:ring-2 focus:ring-teal-500 focus:border-transparent bg-white/70"
                required
              />
              <button type="submit" className="w-full py-3 px-4 bg-gradient-to-r from-teal-500 to-cyan-500 text-white rounded-lg hover:opacity-90 transition-opacity">
                Pay Now
              </button>
            </form>
            {showPaymentSuccess && (
              <div className="mt-4 p-4 bg-gradient-to-br from-green-50 to-emerald-50 text-green-700 rounded-lg border border-green-200">
                Payment successful! Thank you for your payment.
              </div>
            )}
          </div>

          {/* Complaints */}
          <div className="bg-gradient-to-br from-emerald-50 to-teal-50 p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-emerald-200">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-lg">
                <MessageSquare className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                Submit Complaint
              </h3>
            </div>
            <form className="space-y-4" onSubmit={handleComplaint}>
              <input
                type="text"
                placeholder="Your Name"
                className="w-full px-4 py-3 rounded-lg border border-emerald-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent bg-white/70"
                required
              />
              <input
                type="email"
                placeholder="Your Email"
                className="w-full px-4 py-3 rounded-lg border border-emerald-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent bg-white/70"
                required
              />
              <textarea
                placeholder="Describe your complaint"
                rows={3}
                className="w-full px-4 py-3 rounded-lg border border-emerald-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent bg-white/70 resize-none"
                required
              />
              <button type="submit" className="w-full py-3 px-4 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-lg hover:opacity-90 transition-opacity">
                Submit Complaint
              </button>
            </form>
            {showComplaintSuccess && (
              <div className="mt-4 p-4 bg-gradient-to-br from-green-50 to-emerald-50 text-green-700 rounded-lg border border-green-200">
                Your complaint has been submitted successfully. We'll review it shortly.
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}