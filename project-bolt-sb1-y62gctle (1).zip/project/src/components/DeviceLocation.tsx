import { MapPin, Navigation } from 'lucide-react';
import { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix for default marker icons in React-Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

export function DeviceLocation() {
  const [currentLocation, setCurrentLocation] = useState<[number, number]>([11.023349, 77.027487]);
  const [locationError, setLocationError] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation([position.coords.latitude, position.coords.longitude]);
          setLoading(false);
        },
        (error) => {
          let message;
          switch (error.code) {
            case error.PERMISSION_DENIED:
              message = "User denied location access.";
              break;
            case error.POSITION_UNAVAILABLE:
              message = "Location information is unavailable.";
              break;
            case error.TIMEOUT:
              message = "The request to get location timed out.";
              break;
            default:
              message = "An unknown error occurred.";
          }
          setLocationError(message);
          setLoading(false);
        }
      );
    } else {
      setLocationError("Geolocation is not supported by your browser");
      setLoading(false);
    }
  }, []);

  return (
    <section id="device-location" className="section bg-gradient-to-br from-blue-50 via-indigo-50 to-violet-50">
      <div className="container mx-auto">
        <h2 className="text-4xl font-bold text-center mb-12 bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
          Device Location
        </h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-gradient-to-br from-blue-50 to-indigo-100 p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-blue-200">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-lg">
                <MapPin className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-blue-900">
                Current Location
              </h3>
            </div>
            {loading ? (
              <div className="flex items-center justify-center h-[400px]">
                <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
              </div>
            ) : locationError ? (
              <div className="text-red-500 p-4 text-center">
                {locationError}
              </div>
            ) : (
              <div className="h-[400px] w-full rounded-lg overflow-hidden shadow-lg border-2 border-blue-100">
                <MapContainer
                  center={currentLocation}
                  zoom={13}
                  style={{ height: '100%', width: '100%' }}
                >
                  <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                  />
                  <Marker position={currentLocation}>
                    <Popup>
                      <span className="font-semibold">📍 Device Location</span>
                    </Popup>
                  </Marker>
                </MapContainer>
              </div>
            )}
          </div>

          <div className="bg-gradient-to-br from-indigo-50 to-violet-100 p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-indigo-200">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 bg-gradient-to-br from-indigo-500 to-violet-500 rounded-lg">
                <Navigation className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-indigo-900">
                Location Details
              </h3>
            </div>
            <div className="space-y-6">
              <div className="bg-white/50 p-4 rounded-lg border border-indigo-100">
                <h4 className="font-medium text-indigo-900 mb-2">Current Coordinates</h4>
                <p className="text-lg text-indigo-900 font-semibold">
                  {`${currentLocation[0].toFixed(4)}° N, ${currentLocation[1].toFixed(4)}° E`}
                </p>
              </div>
              <div className="bg-white/50 p-4 rounded-lg border border-indigo-100">
                <h4 className="font-medium text-indigo-900 mb-2">Default Location</h4>
                <p className="text-lg text-indigo-900">Sri Ramakrishna Engineering College</p>
              </div>
              <div className="bg-white/50 p-4 rounded-lg border border-indigo-100">
                <h4 className="font-medium text-indigo-900 mb-2">Address</h4>
                <p className="text-lg text-indigo-900">SREC Rd, Vattamalaipalayam, Coimbatore, Tamil Nadu 641022</p>
              </div>
              <div className="bg-white/50 p-4 rounded-lg border border-indigo-100">
                <h4 className="font-medium text-indigo-900 mb-2">Department</h4>
                <p className="text-lg text-indigo-900">Department of Electrical and Electronics Engineering</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}