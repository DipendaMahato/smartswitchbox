import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ChartData,
} from 'chart.js';
import { Line, Bar } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export function Charts() {
  const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          font: {
            size: 14,
            family: "'Poppins', sans-serif"
          },
          padding: 20,
          usePointStyle: true,
          pointStyle: 'circle'
        }
      },
      tooltip: {
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        titleColor: '#1e293b',
        bodyColor: '#1e293b',
        titleFont: {
          size: 16,
          family: "'Poppins', sans-serif"
        },
        bodyFont: {
          size: 14,
          family: "'Poppins', sans-serif"
        },
        padding: 12,
        boxPadding: 6,
        borderColor: 'rgba(0, 0, 0, 0.1)',
        borderWidth: 1
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: 'rgba(0, 0, 0, 0.1)',
          drawBorder: false
        },
        ticks: {
          font: {
            size: 12,
            family: "'Poppins', sans-serif"
          },
          padding: 8
        }
      },
      x: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 12,
            family: "'Poppins', sans-serif"
          },
          padding: 8
        }
      }
    },
    elements: {
      line: {
        tension: 0.4
      },
      point: {
        radius: 4,
        hoverRadius: 6
      }
    }
  };

  const energyData: ChartData<'line'> = {
    labels: months,
    datasets: [{
      label: 'Energy Consumption (kWh)',
      data: [30, 50, 40, 60, 70, 80, 90],
      borderColor: '#3b82f6',
      backgroundColor: 'rgba(59, 130, 246, 0.2)',
      fill: true
    }]
  };

  const costData: ChartData<'bar'> = {
    labels: months,
    datasets: [{
      label: 'Cost (₹)',
      data: [1500, 2500, 2000, 3000, 3500, 4000, 4500],
      backgroundColor: [
        'rgba(99, 102, 241, 0.8)',
        'rgba(168, 85, 247, 0.8)',
        'rgba(236, 72, 153, 0.8)',
        'rgba(245, 158, 11, 0.8)',
        'rgba(16, 185, 129, 0.8)',
        'rgba(59, 130, 246, 0.8)',
        'rgba(139, 92, 246, 0.8)'
      ],
      borderColor: [
        '#6366f1',
        '#a855f7',
        '#ec4899',
        '#f59e0b',
        '#10b981',
        '#3b82f6',
        '#8b5cf6'
      ],
      borderWidth: 1,
      borderRadius: 6,
      hoverBackgroundColor: [
        'rgba(99, 102, 241, 0.9)',
        'rgba(168, 85, 247, 0.9)',
        'rgba(236, 72, 153, 0.9)',
        'rgba(245, 158, 11, 0.9)',
        'rgba(16, 185, 129, 0.9)',
        'rgba(59, 130, 246, 0.9)',
        'rgba(139, 92, 246, 0.9)'
      ]
    }]
  };

  const deviceEfficiencyData: ChartData<'line'> = {
    labels: months,
    datasets: [
      {
        label: 'Device 1 Efficiency (%)',
        data: [75, 80, 85, 82, 88, 90, 92],
        borderColor: '#ef4444',
        backgroundColor: 'rgba(239, 68, 68, 0.2)',
        fill: true
      },
      {
        label: 'Device 2 Efficiency (%)',
        data: [70, 75, 78, 80, 85, 87, 89],
        borderColor: '#3b82f6',
        backgroundColor: 'rgba(59, 130, 246, 0.2)',
        fill: true
      },
      {
        label: 'Device 3 Efficiency (%)',
        data: [65, 70, 75, 78, 80, 83, 85],
        borderColor: '#10b981',
        backgroundColor: 'rgba(16, 185, 129, 0.2)',
        fill: true
      },
      {
        label: 'Device 4 Efficiency (%)',
        data: [60, 65, 70, 75, 78, 80, 82],
        borderColor: '#f59e0b',
        backgroundColor: 'rgba(245, 158, 11, 0.2)',
        fill: true
      }
    ]
  };

  const powerUsageData: ChartData<'bar'> = {
    labels: months,
    datasets: [{
      label: 'Power Usage (Watts)',
      data: [2000, 2200, 1800, 2400, 2600, 2800, 3000],
      backgroundColor: [
        'rgba(245, 158, 11, 0.8)',
        'rgba(16, 185, 129, 0.8)',
        'rgba(59, 130, 246, 0.8)',
        'rgba(139, 92, 246, 0.8)',
        'rgba(236, 72, 153, 0.8)',
        'rgba(99, 102, 241, 0.8)',
        'rgba(168, 85, 247, 0.8)'
      ],
      borderColor: [
        '#f59e0b',
        '#10b981',
        '#3b82f6',
        '#8b5cf6',
        '#ec4899',
        '#6366f1',
        '#a855f7'
      ],
      borderWidth: 1,
      borderRadius: 6,
      hoverBackgroundColor: [
        'rgba(245, 158, 11, 0.9)',
        'rgba(16, 185, 129, 0.9)',
        'rgba(59, 130, 246, 0.9)',
        'rgba(139, 92, 246, 0.9)',
        'rgba(236, 72, 153, 0.9)',
        'rgba(99, 102, 241, 0.9)',
        'rgba(168, 85, 247, 0.9)'
      ]
    }]
  };

  return (
    <section id="charts" className="section bg-gradient-to-br from-indigo-50 via-blue-50 to-violet-50">
      <div className="container mx-auto">
        <h2 className="text-4xl font-bold text-center mb-12 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
          Usage Analytics
        </h2>

        <div className="text-center mb-8">
          <a 
            href="https://stem.ubidots.com/app/dashboards/677a44d72e973d000b9fe842?devices=677a265cb1f194000d17cc17"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-primary to-secondary text-white rounded-lg hover:opacity-90 transition-opacity"
          >
            <span>View Real-Time Energy Consumption Data</span>
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </a>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-gradient-to-br from-blue-50 to-indigo-100 p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-blue-200">
            <h3 className="text-xl font-bold mb-6 text-blue-900">Energy Consumption Trends</h3>
            <Line data={energyData} options={chartOptions} />
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-fuchsia-100 p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-purple-200">
            <h3 className="text-xl font-bold mb-6 text-purple-900">Monthly Cost Analysis</h3>
            <Bar data={costData} options={chartOptions} />
          </div>

          <div className="bg-gradient-to-br from-green-50 to-emerald-100 p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-green-200">
            <h3 className="text-xl font-bold mb-6 text-green-900">Device Efficiency Comparison</h3>
            <Line data={deviceEfficiencyData} options={chartOptions} />
          </div>

          <div className="bg-gradient-to-br from-amber-50 to-orange-100 p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-amber-200">
            <h3 className="text-xl font-bold mb-6 text-amber-900">Power Usage Distribution</h3>
            <Bar data={powerUsageData} options={chartOptions} />
          </div>
        </div>
      </div>
    </section>
  );
}