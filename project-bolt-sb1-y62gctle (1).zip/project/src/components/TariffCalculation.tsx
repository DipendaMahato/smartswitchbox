import { Calculator } from 'lucide-react';
import { useState } from 'react';

export function TariffCalculation() {
  const [rate, setRate] = useState('');
  const [consumption, setConsumption] = useState('');
  const [total, setTotal] = useState<number | null>(null);

  const calculateTariff = (e: React.FormEvent) => {
    e.preventDefault();
    const calculatedTotal = Number(rate) * Number(consumption);
    setTotal(calculatedTotal);
  };

  return (
    <section id="tariff-calculation" className="section bg-gradient-to-br from-amber-50 via-orange-50 to-red-50">
      <div className="container mx-auto max-w-2xl">
        <h2 className="text-4xl font-bold text-center mb-12 bg-gradient-to-r from-amber-600 to-red-600 bg-clip-text text-transparent">
          Tariff Calculator
        </h2>

        <div className="bg-gradient-to-br from-amber-50 to-orange-100 p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-amber-200">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 bg-gradient-to-br from-amber-500 to-orange-500 rounded-lg">
              <Calculator className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-amber-900">
              Calculate Your Bill
            </h3>
          </div>

          <form onSubmit={calculateTariff} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-amber-800 mb-2">
                Rate per kWh (₹)
              </label>
              <input
                type="number"
                value={rate}
                onChange={(e) => setRate(e.target.value)}
                className="w-full px-4 py-3 rounded-lg border border-amber-200 focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white/70"
                placeholder="Enter rate"
                step="0.01"
                min="0"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-amber-800 mb-2">
                Consumption (kWh)
              </label>
              <input
                type="number"
                value={consumption}
                onChange={(e) => setConsumption(e.target.value)}
                className="w-full px-4 py-3 rounded-lg border border-amber-200 focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white/70"
                placeholder="Enter consumption"
                min="0"
                required
              />
            </div>

            <button type="submit" className="w-full py-3 px-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-lg hover:opacity-90 transition-opacity">
              Calculate
            </button>
          </form>

          {total !== null && (
            <div className="mt-6 p-6 bg-white/50 rounded-lg border border-amber-200">
              <h4 className="text-lg font-semibold text-amber-800">Total Cost</h4>
              <p className="text-3xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
                ₹{total.toFixed(2)}
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}