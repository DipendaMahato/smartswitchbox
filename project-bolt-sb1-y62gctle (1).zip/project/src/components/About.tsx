import { Activity, Battery, Zap } from 'lucide-react';

export function About() {
  return (
    <section id="about" className="section bg-gradient-to-br from-indigo-50 via-blue-50 to-violet-50">
      <div className="container mx-auto">
        <div className="flex flex-col lg:flex-row gap-12 items-center">
          <div className="lg:w-1/2 relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-primary to-secondary rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
            <img 
              src="https://i.ibb.co/zWv0DtRK/IMG-20241218-WA0005.jpg"
              alt="Smart Switch Box" 
              className="relative rounded-2xl shadow-xl hover:scale-105 transition-transform duration-300 object-cover h-[400px] w-full"
            />
          </div>
          
          <div className="lg:w-1/2">
            <h2 className="text-4xl font-bold mb-6 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              About Project
            </h2>
            <div className="prose prose-lg">
              <p className="mb-6 text-lg leading-relaxed text-gray-700 font-medium">
                The Smart Multifunction Switch Box is an innovative IoT device that bridges the gap between modern and traditional appliances, providing seamless integration and enhanced automation for your smart home needs.
              </p>
              
              <div className="space-y-6">
                <div className="transform hover:scale-105 transition-transform duration-300">
                  <div className="flex items-start gap-4 bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-xl shadow-md border border-blue-100">
                    <div className="p-3 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg text-white">
                      <Zap className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-bold text-xl text-blue-900 mb-2">Smart Control</h3>
                      <p className="text-blue-800">Features versatile control options including Wi-Fi, Bluetooth, remote control, and voice commands for ultimate convenience.</p>
                    </div>
                  </div>
                </div>

                <div className="transform hover:scale-105 transition-transform duration-300">
                  <div className="flex items-start gap-4 bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-xl shadow-md border border-green-100">
                    <div className="p-3 bg-gradient-to-br from-green-500 to-green-600 rounded-lg text-white">
                      <Activity className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-bold text-xl text-green-900 mb-2">Real-time Monitoring</h3>
                      <p className="text-green-800">Advanced energy monitoring with customized alerts and automated scheduling for optimized usage and efficiency.</p>
                    </div>
                  </div>
                </div>

                <div className="transform hover:scale-105 transition-transform duration-300">
                  <div className="flex items-start gap-4 bg-gradient-to-r from-purple-50 to-fuchsia-50 p-6 rounded-xl shadow-md border border-purple-100">
                    <div className="p-3 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg text-white">
                      <Battery className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-bold text-xl text-purple-900 mb-2">Safety Features</h3>
                      <p className="text-purple-800">Built-in fault detection and surge protection mechanisms with environmental sensors for maximum safety.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
          <div className="bg-gradient-to-br from-blue-50 to-indigo-100 p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-blue-200">
            <div className="text-4xl font-bold text-blue-600 mb-2">30%</div>
            <h3 className="text-xl font-bold text-blue-900 mb-2">Energy Savings</h3>
            <p className="text-blue-800">Significant reduction in energy consumption through smart monitoring and optimization</p>
          </div>
          
          <div className="bg-gradient-to-br from-green-50 to-emerald-100 p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-green-200">
            <div className="text-4xl font-bold text-green-600 mb-2">25%</div>
            <h3 className="text-xl font-bold text-green-900 mb-2">Cost Savings</h3>
            <p className="text-green-800">Substantial reduction in energy bills through efficient power management</p>
          </div>
          
          <div className="bg-gradient-to-br from-purple-50 to-fuchsia-100 p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-purple-200">
            <div className="text-4xl font-bold text-purple-600 mb-2">95%</div>
            <h3 className="text-xl font-bold text-purple-900 mb-2">Increased Efficiency</h3>
            <p className="text-purple-800">Optimized energy usage for maximum efficiency and performance</p>
          </div>
        </div>
      </div>
    </section>
  );
}