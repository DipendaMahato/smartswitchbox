import { useState } from 'react';
import { ZoomIn } from 'lucide-react';

export function Gallery() {
  const images = [
    'https://i.ibb.co/cSs0Lk1C/IMG-20250307-105439.jpg',
    'https://i.ibb.co/zWv0DtRK/IMG-20241218-WA0005.jpg',
    'https://i.ibb.co/RkWkHkKx/IMG-20250307-105412.jpg',
    'https://i.ibb.co/WWZpYsn0/IMG-20250307-110223.jpg',
    'https://i.ibb.co/nsD4DZbP/IMG-20250128-WA0037.jpg'
  ];

  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  return (
    <section id="gallery" className="section bg-gradient-to-br from-purple-50 to-pink-50 overflow-hidden">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12 text-gray-900">Gallery</h2>
        
        <div className="relative w-full overflow-hidden">
          <div className="flex animate-slide">
            {/* First set of images */}
            {images.map((src, index) => (
              <div 
                key={`first-${index}`}
                className="min-w-[300px] h-[400px] mx-4 relative rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer"
                onClick={() => setSelectedImage(src)}
              >
                <img 
                  src={src} 
                  alt={`Smart Switch Box ${index + 1}`}
                  className="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black/50 opacity-0 hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <ZoomIn className="w-10 h-10 text-white" />
                </div>
              </div>
            ))}
            {/* Duplicate set for seamless loop */}
            {images.map((src, index) => (
              <div 
                key={`second-${index}`}
                className="min-w-[300px] h-[400px] mx-4 relative rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer"
                onClick={() => setSelectedImage(src)}
              >
                <img 
                  src={src} 
                  alt={`Smart Switch Box ${index + 1}`}
                  className="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black/50 opacity-0 hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <ZoomIn className="w-10 h-10 text-white" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Modal for enlarged image */}
        {selectedImage && (
          <div 
            className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedImage(null)}
          >
            <div className="relative max-w-5xl w-full">
              <img 
                src={selectedImage} 
                alt="Enlarged view"
                className="w-full h-auto rounded-lg"
              />
              <button 
                className="absolute top-4 right-4 text-white text-xl font-bold"
                onClick={() => setSelectedImage(null)}
              >
                ×
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}