import { Wifi, Smartphone, Plus, Settings } from 'lucide-react';

export function HowItWorks() {
  const steps = [
    {
      icon: <Wifi className="w-8 h-8" />,
      title: "Connect to Wi-Fi",
      description: "Power on your Smart Switch Box and connect it to your home Wi-Fi network",
      gradient: "from-blue-50 to-indigo-100",
      iconGradient: "from-blue-500 to-blue-600",
      textColor: "blue",
      borderColor: "blue-200"
    },
    {
      icon: <Smartphone className="w-8 h-8" />,
      title: "Download the App",
      description: "Get our mobile app from your device's app store",
      gradient: "from-purple-50 to-fuchsia-100",
      iconGradient: "from-purple-500 to-purple-600",
      textColor: "purple",
      borderColor: "purple-200"
    },
    {
      icon: <Plus className="w-8 h-8" />,
      title: "Add Your Devices",
      description: "Add and configure your appliances through the app interface",
      gradient: "from-green-50 to-emerald-100",
      iconGradient: "from-green-500 to-green-600",
      textColor: "green",
      borderColor: "green-200"
    },
    {
      icon: <Settings className="w-8 h-8" />,
      title: "Control and Monitor",
      description: "Start controlling your devices and monitoring energy usage",
      gradient: "from-amber-50 to-orange-100",
      iconGradient: "from-amber-500 to-orange-600",
      textColor: "amber",
      borderColor: "amber-200"
    }
  ];

  return (
    <section id="how-it-works" className="section bg-gradient-to-br from-indigo-50 via-blue-50 to-violet-50">
      <div className="container mx-auto">
        <h2 className="text-4xl font-bold text-center mb-12 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
          How It Works
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <div className={`bg-gradient-to-br ${step.gradient} p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-${step.borderColor}`}>
                <div className={`bg-gradient-to-br ${step.iconGradient} p-4 rounded-lg text-white inline-block mb-6`}>
                  {step.icon}
                </div>
                <h3 className={`text-xl font-bold text-${step.textColor}-900 mb-3`}>{step.title}</h3>
                <p className={`text-${step.textColor}-800`}>{step.description}</p>
              </div>
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-4 w-8 h-0.5 bg-gradient-to-r from-primary to-secondary" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}