import { useState } from 'react';
import { Home } from './components/Home';
import { About } from './components/About';
import { Features } from './components/Features';
import { Gallery } from './components/Gallery';
import { HowItWorks } from './components/HowItWorks';
import { GovernmentPortal } from './components/GovernmentPortal';
import { TariffCalculation } from './components/TariffCalculation';
import { Charts } from './components/Charts';
import { Contact } from './components/Contact';
import { Navigation } from './components/Navigation';
import { DeviceLocation } from './components/DeviceLocation';

function App() {
  const [activeSection, setActiveSection] = useState('home');

  return (
    <div className="app">
      <Navigation activeSection={activeSection} setActiveSection={setActiveSection} />
      <main>
        <Home />
        <About />
        <Features />
        <Gallery />
        <HowItWorks />
        <Charts />
        <DeviceLocation />
        <GovernmentPortal />
        <TariffCalculation />
        <Contact />
      </main>
    </div>
  );
}

export default App;